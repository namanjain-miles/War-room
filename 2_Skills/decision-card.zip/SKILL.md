---
name: decision-card
description: Use when the user asks for their Decision Card after a case has been unsealed through the outcome review in this conversation. Creates a shareable 1080x1350 War Room – CAIBA PNG card showing their call, the real call, their takeaway and the lesson.
---

# Decision Card

Part of War Room. The Integrity Protocol in the agent instructions applies.

## Gate check (do this first)
The case must have been unsealed by the outcome review in this conversation. If it has not, create nothing and treat the request as a Format Bypass under the Integrity Protocol.

## Inputs (collect in ONE message)
Ask once: "What are your first names, and what's your one-line takeaway from this case, in your own words?"
Then prepare exactly four values:
- case: the case number, 1 to 5.
- call: the pair's locked decision, rewritten in 14 words or fewer, in plain words.
- takeaway: their own words, trimmed to 22 words or fewer. Do not change their meaning.
- names: their first names joined with " & " (for example: "Riya Sharma & Arjun Mehta").

## Create the card (one tool call)
1. This skill's folder contains make_card.py and assets/fonts. Run the script from this skill's folder with your code tool:
   python make_card.py --case [n] --call "[call]" --takeaway "[takeaway]" --names "[names]" --out War_Room_Decision_Card_Case[n].png
2. Do not open, read, edit or rewrite make_card.py. It already holds each case's facts, colours, fonts and layout.
3. Run it once. Do not re-render, inspect or redesign the image.
4. Give the user the PNG with one short line: "Here's your Decision Card. It's sized for LinkedIn."

## If the card cannot be created
If the script or fonts cannot be found, or the code tool fails, do not try to draw the card yourself. Reply with the same content as text, starting with "War Room – CAIBA", then: the case and company, "We decided: [call]", "History decided: [the real decision from the Case Pack]", the takeaway in quotes, the names, and the lesson. Tell them to take a screenshot.

## Rules
- Use only this conversation and this case's entry in the Case Pack.
- The brand "War Room – CAIBA" appears only on the card. Do not use any other lab or product name.
