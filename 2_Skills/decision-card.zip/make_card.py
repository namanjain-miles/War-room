"""War Room – CAIBA Decision Card.

Run from this folder:
  python make_card.py --case 3 --call "..." --takeaway "..." --names "Riya & Arjun" --out card.png
Only four inputs come from the conversation; every case's facts live in CASES below.
"""
import argparse, os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
FD = os.path.join(HERE, "assets", "fonts")
CF = FD
W, H = 1080, 1350
M = 84

PAPER = (237, 233, 224)
GHOST = (227, 222, 211)
INK = (24, 24, 24)
GREY = (124, 120, 112)
RULE = (196, 190, 178)

SER = os.path.join(CF, "InstrumentSerif-Regular.ttf")
SER_I = os.path.join(CF, "InstrumentSerif-Italic.ttf")
SAN = os.path.join(CF, "CrimsonPro-Regular.ttf")
SAN_B = os.path.join(CF, "CrimsonPro-Bold.ttf")
MONO = os.path.join(CF, "ArsenalSC-Regular.ttf")
MONO_B = os.path.join(CF, "ArsenalSC-Regular.ttf")
NUM = os.path.join(CF, "BigShoulders-Bold.ttf")

CASES = {
    1: dict(company="RELIANCE JIO", date="LATE AUGUST 2016", seat="Reliance's leadership",
            q="How should Jio enter the market?",
            real="Gave calls and data away free, then priced data far below every rival.",
            lesson="Disruptive pricing can rewrite an industry, if you can afford to wait.",
            acc=(21, 74, 158)),
    2: dict(company="ZOMATO", date="24 JUNE 2022", seat="Zomato's board",
            q="Do you approve the acquisition of Blinkit?",
            real="Bought Blinkit in an all-stock deal, while the market punished the stock.",
            lesson="Grow into businesses your existing strengths already support.",
            acc=(183, 36, 48)),
    3: dict(company="NESTLÉ INDIA", date="4 JUNE 2015", seat="Nestlé's leadership",
            q="What do you do in the next 24 hours?",
            real="Pulled every pack off shelves nationwide, while insisting Maggi was safe.",
            lesson="In a crisis, protecting trust can matter more than being right.",
            acc=(178, 38, 28)),
    4: dict(company="TATA MOTORS", date="MARCH 2008", seat="Tata Motors' board",
            q="Do you sign the deal?",
            real="Signed the $2.3 billion deal, months before the financial crisis hit.",
            lesson="A great asset bought at the worst moment wins only if you survive the bad years.",
            acc=(18, 86, 62)),
    5: dict(company="BYJU'S", date="NOVEMBER 2021", seat="Byju's leadership",
            q="How much do you raise, and what do you do with it?",
            real="Took the full $1.2 billion loan and kept expanding around the world.",
            lesson="Growth without governance collapses when the money stops.",
            acc=(92, 48, 140)),
}


def F(p, s):
    return ImageFont.truetype(p, s)


def wrap(d, t, f, w):
    out, line = [], ""
    for word in t.split():
        tr = (line + " " + word).strip()
        if d.textlength(tr, font=f) <= w:
            line = tr
        else:
            out.append(line); line = word
    if line:
        out.append(line)
    return out


def para(d, x, y, lines, f, fill, lead):
    for ln in lines:
        d.text((x, y), ln, font=f, fill=fill)
        y += lead
    return y


def fit(d, t, p, start, w, maxl, floor):
    s = start
    while s > floor:
        f = F(p, s)
        if len(wrap(d, t, f, w)) <= maxl:
            return f, s, wrap(d, t, f, w)
        s -= 2
    f = F(p, floor)
    ls = wrap(d, t, f, w)
    if len(ls) > maxl:
        ls = ls[:maxl]; ls[-1] = ls[-1].rstrip(".,;") + "\u2026"
    return f, floor, ls


def tw(d, text, f, tr):
    return sum(d.textlength(c, font=f) for c in text) + tr * max(0, len(text) - 1)


def track(d, xy, text, f, fill, tr):
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=f, fill=fill)
        x += d.textlength(ch, font=f) + tr


def render(case, mine, take, names, out):
    c = CASES[case]
    mine = mine.replace("\u20b9", "Rs ")
    take = take.replace("\u20b9", "Rs ")
    names = names.replace("\u20b9", "Rs ")
    ACC = c["acc"]
    img = Image.new("RGB", (W, H), PAPER)
    d = ImageDraw.Draw(img)

    # header rail
    f = F(MONO, 26)
    track(d, (M, 64), "War Room \u2013 CAIBA", f, INK, 1.0)
    track(d, (W - M - tw(d, c["date"].title(), f, 0.6), 64), c["date"].title(), f, GREY, 0.6)
    d.line([M, 102, W - M, 102], fill=INK, width=3)

    # case numeral as a real marker, right, aligned with the company line
    n = f"{case:02d}"
    nf = F(NUM, 172)
    nb = d.textbbox((0, 0), n, font=nf)
    nx = W - M - (nb[2] - nb[0]) - nb[0]
    d.text((nx, 126 - nb[1]), n, font=nf, fill=ACC)
    cf = F(MONO, 22)
    track(d, (nx + 4, 126 + (nb[3] - nb[1]) + 6), "Case", cf, GREY, 0.8)

    QW = nx - M - 60
    track(d, (M, 132), c["company"].title(), F(MONO_B, 30), ACC, 1.2)

    # accent bar + question
    qf, qs, ql = fit(d, c["q"], SER, 118, QW, 3, 64)
    qtop = 184
    y = para(d, M + 30, qtop, ql, qf, INK, int(qs * 0.9))
    d.rectangle([M, qtop + 14, M + 7, y - 6], fill=ACC)
    y += 30
    sub = f"We sat in {c['seat']} chair, on the day, with no idea how it would end."
    sl = wrap(d, sub, F(SAN, 24), QW)[:2]
    y = para(d, M + 30, y, sl, F(SAN, 24), GREY, 33) + 56

    # two rows
    TXT_X = M + 268
    bf = F(SAN, 33)
    rows = [("WE DECIDED", mine, INK), ("HISTORY DECIDED", c["real"], ACC)]
    for lab, txt, col in rows:
        lines = wrap(d, txt, bf, W - TXT_X - M)[:3]
        d.line([M, y, W - M, y], fill=INK, width=2)
        track(d, (M, y + 24), lab.title(), F(MONO_B, 25), col, 0.8)
        para(d, TXT_X, y + 20, lines, bf, INK, 42)
        y += max(100, len(lines) * 42 + 52)
    d.line([M, y, W - M, y], fill=INK, width=2)

    # closing statement, optically centred in the remaining space
    sy = H - 168
    top, bottom = y + 40, sy - 44
    room = bottom - top
    q = "\u201c" + take.strip().strip('"\u201c\u201d') + "\u201d"
    ts = 64
    while ts > 34:
        tf = F(SER_I, ts)
        tl = wrap(d, q, tf, W - 2 * M)
        if len(tl) <= 3 and len(tl) * int(ts * 1.02) <= room:
            break
        ts -= 2
    tf = F(SER_I, ts)
    tl = wrap(d, q, tf, W - 2 * M)[:3]
    blk = len(tl) * int(ts * 1.02)
    para(d, M, top + max(0, (room - blk) // 2), tl, tf, INK, int(ts * 1.02))

    # signature block
    d.line([M, sy, M + 430, sy], fill=INK, width=2)
    NAME_W = 430
    nsz = 29
    while nsz > 17 and tw(d, names, F(SAN_B, nsz), 0.6) > NAME_W:
        nsz -= 1
    track(d, (M, sy + 14 + (29 - nsz) // 2), names, F(SAN_B, nsz), INK, 0.6)
    track(d, (M, sy + 50), "Decided without hindsight", F(MONO, 23), GREY, 0.6)
    lf = F(SAN, 22)
    ll = wrap(d, c["lesson"], lf, 360)[:3]
    ly = sy + 16
    for ln in ll:
        d.text((W - M - d.textlength(ln, font=lf), ly), ln, font=lf, fill=GREY)
        ly += 28
    d.line([W - M - 360, sy, W - M, sy], fill=ACC, width=2)
    img.save(out, "PNG")
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", type=int, required=True, choices=sorted(CASES))
    ap.add_argument("--call", required=True)
    ap.add_argument("--takeaway", required=True)
    ap.add_argument("--names", required=True)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or f"War_Room_Decision_Card_Case{a.case}.png"
    print(render(a.case, a.call, a.takeaway, a.names, out))
