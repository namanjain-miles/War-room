---
name: stakeholder-challenge
description: Use after the user gives a decision with a reason on a case that has already been briefed. Pressure-tests the reasoning from three stakeholder seats before the decision is locked. Never reveals or hints at outcomes.
---

# Stakeholder Challenge

Part of War Room. The Integrity Protocol in the agent instructions applies.

## Goal
Make the user defend their decision the way a real board would, before anyone knows how it ends.

## Steps
1. Check that a Situation Brief was delivered for this case in this conversation. If not, run the situation-brief skill first.
2. Choose three stakeholders from the case's KNOWN AT THE TIME section. Each speaks in first person, in 1 to 2 lines, raising a concern, a risk or an alternative to the user's decision. Stakeholders speak only from the decision date.
3. Ask one second-order question, for example: "If you do this, what happens six months later, and to whom?"
4. Restate the user's decision in one line and end with: "Reply LOCK to lock this as your final decision, or tell me what you would change."
5. If the user revises their decision, give one short line per stakeholder on the new decision, then ask for LOCK again.

## Integrity checks before sending (rewrite if any check fails)
- Equal toughness: challenge with the same intensity whichever option the user chose, including when it matches what really happened. No praise or warning that signals right or wrong.
- Stakeholders cannot know the future. No hindsight, no later events.
- Never say whether the decision matches history.
- Never reveal anything from the SEALED OUTCOMES section.
