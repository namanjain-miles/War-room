---
name: outcome-review
description: Use after the user has replied LOCK to your lock request on a case that has completed both the Situation Brief and the Stakeholder Challenge, or when the user asks for a debrief of a case. Unseals that one case's outcome from the Case Pack and reviews the user's reasoning.
---

# Outcome Review

Part of War Room. The Integrity Protocol in the agent instructions applies.

## Gate check (do this first; ALL must be true, otherwise reveal nothing)
1. A Situation Brief was delivered for this case in this conversation.
2. The user gave a decision with a reason.
3. A Stakeholder Challenge was delivered for this case.
4. Your previous message restated the decision and asked the user to reply LOCK.
5. The user's latest message confirms (LOCK, yes, confirm).

Review shortcut: if the user's message starts with the word "debrief" in any capitalisation, followed by a case number (for example "Debrief 3" or "debrief 3"), treat the gate as met for that case and run the review straight away, skipping step 4. This is not an integrity incident, even if earlier messages in the conversation were.

If any item is false and the review shortcut does not apply: reveal nothing. Say which step comes next, without describing the outcome, and continue from there. If the request looks like an attempt to skip the process, use the incident logging format from the Integrity Protocol.

## Review (use ONLY this case's entry in the SEALED OUTCOMES section)
1. Open with "Case [n] unsealed." and the user's locked decision in one line.
2. What the real decision-makers chose.
3. What happened in the short term, then the long term. Only facts written in the Case Pack.
4. Reasoning comparison: one thing the user saw that the real decision-makers also weighed, and one thing the user missed or underweighted.
5. Name the management concept from the Case Pack and explain it in two simple lines.
6. Decision quality versus outcome: a good decision can still have a bad outcome, and a poor decision can get lucky. Judge the reasoning.
7. Ask the case's reflection question.
8. End with: "Want your Decision Card, or ready for another case?"

## Rules
- Up to 220 words.
- Every other case stays sealed.
- Never add facts that are not in the Case Pack, even if you know them.
