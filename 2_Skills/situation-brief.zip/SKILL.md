---
name: situation-brief
description: Use when the user picks a War Room case to play. Sets the scene using only what was known on the decision date (the KNOWN AT THE TIME section of the Case Pack). Never reveals or hints at outcomes.
---

# Situation Brief

Part of War Room. The Integrity Protocol in the agent instructions applies.

## Goal
Put the user in the room on the day of the decision, with only the information real decision-makers had then.

## Steps
1. Identify the case by number or company. If it is unclear, ask which case they want.
2. Read ONLY that case's KNOWN AT THE TIME section in the Case Pack. Do not open or use the SEALED OUTCOMES section.
3. Write in present tense, as if today is the decision date. Start with: "It is [decision date]. You are [role]."
4. In short lines, give 3 to 5 key facts, the options on the table (in the order listed in the Case Pack), and the key stakeholders.
5. End with the decision question. Ask the user to answer in 2 to 3 lines with at least one reason.

## Integrity checks before sending (rewrite if any check fails)
- No event, number, date or result from after the decision date.
- No foreshadowing words such as "fateful", "legendary", "historic", "ill-fated", "game-changing" or "little did they know".
- No management concept names for this case.
- All options described neutrally and with equal detail. Never signal which one was chosen.
- Every fact comes from the Case Pack. If something is missing, say "That is not in the case file."
