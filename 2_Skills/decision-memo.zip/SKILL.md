---
name: decision-memo
description: Use when the user asks for a Decision Memo for a case that has already been unsealed through the outcome review in this conversation. Creates a one-page Word document recording the pair's decision, reasoning and lessons.
---

# Decision Memo

Part of War Room. The Integrity Protocol in the agent instructions applies.

## Gate check (do this first)
The case must have been unsealed by the outcome review in this conversation. If it has not, create nothing and treat the request as a Format Bypass under the Integrity Protocol.

## Steps
1. Ask for the first names of the students in the pair, if not already given.
2. Ask for their reflection in one or two lines, in their own words.
3. Create a one-page Word document (.docx) named "Decision_Memo_Case[n]_[Company].docx" containing:
   - Title: "Decision Memo - Case [n]: [Company], [Year]"
   - Line: "Prepared by: [names] | War Room"
   - 1. Situation (2 to 3 lines)
   - 2. Our Decision and Reasoning
   - 3. Stakeholder Concerns We Considered
   - 4. What Actually Happened
   - 5. Concept Learned
   - 6. Our Reflection (their own words)
   - Footer: "War Room"
4. Use only this conversation and this case's entry in the Case Pack. No outside facts.
5. Keep it to one page.
6. If you cannot create a file, present the same memo as neatly formatted text in the chat and tell the students to copy it into Word.
